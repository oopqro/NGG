package guessinggame;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Leaderboard {
    private final File file;

    public Leaderboard(String fileName) {
        this.file = new File(fileName);
    }

    public void addEntry(LeaderboardEntry entry) {
        try (FileWriter fw = new FileWriter(file, true)) {
            fw.write(entry.getUsername() + "," + entry.getRole() + "," + entry.getDifficulty() + "," + entry.getLevel() + "," + entry.getScore() + System.lineSeparator());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public List<LeaderboardEntry> readEntries() {
        List<LeaderboardEntry> entries = new ArrayList<>();

        if (!file.exists()) {
            return entries;
        }

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 5) {
                    try {
                        entries.add(new LeaderboardEntry(
                                parts[0],
                                parts[1],
                                parts[2],
                                Integer.parseInt(parts[3]),
                                Integer.parseInt(parts[4])
                        ));
                    } catch (NumberFormatException ignored) {
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        entries.sort(Comparator.comparingInt(LeaderboardEntry::getScore).reversed());
        return entries;
    }

    public String formatTopEntries(int limit) {
        List<LeaderboardEntry> entries = readEntries();
        if (entries.isEmpty()) {
            return "No scores yet.";
        }

        StringBuilder sb = new StringBuilder();
        int count = Math.min(limit, entries.size());
        for (int i = 0; i < count; i++) {
            sb.append(i + 1).append(". ").append(entries.get(i)).append(System.lineSeparator());
        }
        return sb.toString();
    }

    public void clear() {
        try (FileWriter fw = new FileWriter(file, false)) {
            fw.write("");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
