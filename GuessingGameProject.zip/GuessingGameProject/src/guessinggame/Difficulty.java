package guessinggame;

public enum Difficulty {
    EASY("Easy", 50, 7, 100),
    MEDIUM("Medium", 100, 6, 120),
    HARD("Hard", 200, 5, 150);

    private final String label;
    private final int maxNumber;
    private final int maxAttempts;
    private final int startingScore;

    Difficulty(String label, int maxNumber, int maxAttempts, int startingScore) {
        this.label = label;
        this.maxNumber = maxNumber;
        this.maxAttempts = maxAttempts;
        this.startingScore = startingScore;
    }

    public String getLabel() {
        return label;
    }

    public int getMaxNumber() {
        return maxNumber;
    }

    public int getMaxAttempts() {
        return maxAttempts;
    }

    public int getStartingScore() {
        return startingScore;
    }

    @Override
    public String toString() {
        return label;
    }
}
