package guessinggame;

public class LeaderboardEntry {
    private final String username;
    private final String role;
    private final String difficulty;
    private final int level;
    private final int score;

    public LeaderboardEntry(String username, String role, String difficulty, int level, int score) {
        this.username = username;
        this.role = role;
        this.difficulty = difficulty;
        this.level = level;
        this.score = score;
    }

    public String getUsername() {
        return username;
    }

    public String getRole() {
        return role;
    }

    public String getDifficulty() {
        return difficulty;
    }

    public int getLevel() {
        return level;
    }

    public int getScore() {
        return score;
    }

    @Override
    public String toString() {
        return username + " | " + role + " | " + difficulty + " | Level " + level + " | Score " + score;
    }
}
