package guessinggame;

public class Level {
    private int number;
    private int max;
    private int attempts;
    private int maxAttempts;
    private int score;
    private int level;
    private Difficulty difficulty;

    public Level(Difficulty difficulty) {
        this.difficulty = difficulty;
        resetGame();
    }

    public void resetGame() {
        level = 1;
        max = difficulty.getMaxNumber();
        maxAttempts = difficulty.getMaxAttempts();
        start();
    }

    public void start() {
        number = (int) (Math.random() * (max + 1));
        attempts = 0;
        score = difficulty.getStartingScore();
    }

    public void nextLevel() {
        level++;
        max += 50;
        if (maxAttempts > 3) {
            maxAttempts--;
        }
        start();
    }

    public String check(int guess) {
        attempts++;

        if (guess == number) {
            return "win";
        }

        score -= 10;
        if (score < 0) {
            score = 0;
        }

        if (guess < number) {
            return "greater";
        }
        return "smaller";
    }

    public int getNumber() {
        return number;
    }

    public int getMax() {
        return max;
    }

    public int getAttempts() {
        return attempts;
    }

    public int getMaxAttempts() {
        return maxAttempts;
    }

    public int getScore() {
        return score;
    }

    public int getLevel() {
        return level;
    }

    public Difficulty getDifficulty() {
        return difficulty;
    }
}
