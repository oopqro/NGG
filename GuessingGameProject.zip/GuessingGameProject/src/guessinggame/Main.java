package guessinggame;

public class Main {
    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(GUI::new);
    }
}
