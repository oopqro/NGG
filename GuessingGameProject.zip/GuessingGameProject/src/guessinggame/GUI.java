package guessinggame;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class GUI extends JFrame {
    private final User currentUser;
    private final Leaderboard leaderboard = new Leaderboard("leaderboard.txt");
    private Level game;

    private final JTextField input = new JTextField();
    private final JTextArea output = new JTextArea();
    private final JButton guessButton = new JButton("GUESS");
    private final JButton showBoardButton = new JButton("LEADERBOARD");
    private final JButton resetButton = new JButton("NEW GAME");
    private JButton clearBoardButton;

    private final JLabel userLabel = new JLabel();
    private final JLabel levelLabel = new JLabel();
    private final JLabel scoreLabel = new JLabel();
    private final JLabel infoLabel = new JLabel();

    private final int[] guesses = new int[100];
    private int top = -1;

    public GUI() {
        currentUser = createUser();
        Difficulty difficulty = chooseDifficulty();
        game = new Level(difficulty);

        setTitle("Guessing Game");
        setSize(700, 500);
        setLayout(new BorderLayout(8, 8));
        getContentPane().setBackground(new Color(245, 247, 250));

        JPanel topPanel = new JPanel(new GridLayout(2, 2, 8, 8));
        topPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 0, 10));
        topPanel.setBackground(new Color(245, 247, 250));

        topPanel.add(userLabel);
        topPanel.add(levelLabel);
        topPanel.add(scoreLabel);
        topPanel.add(infoLabel);

        output.setEditable(false);
        output.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));

        JPanel bottom = new JPanel(new BorderLayout(8, 8));
        bottom.setBorder(BorderFactory.createEmptyBorder(0, 10, 10, 10));
        bottom.setBackground(new Color(245, 247, 250));

        JPanel buttonPanel = new JPanel(new GridLayout(1, 3 + (currentUser instanceof AdminUser ? 1 : 0), 8, 8));
        buttonPanel.setBackground(new Color(245, 247, 250));
        buttonPanel.add(guessButton);
        buttonPanel.add(showBoardButton);
        buttonPanel.add(resetButton);

        if (currentUser instanceof AdminUser) {
            clearBoardButton = new JButton("CLEAR BOARD");
            buttonPanel.add(clearBoardButton);
            clearBoardButton.addActionListener(e -> clearLeaderboard());
        }

        bottom.add(input, BorderLayout.CENTER);
        bottom.add(buttonPanel, BorderLayout.SOUTH);

        add(topPanel, BorderLayout.NORTH);
        add(new JScrollPane(output), BorderLayout.CENTER);
        add(bottom, BorderLayout.SOUTH);

        game.start();
        updateLabels();
        output.append("Game started. Guess a number from 0 to " + game.getMax() + System.lineSeparator());

        guessButton.addActionListener(e -> play());
        showBoardButton.addActionListener(e -> showLeaderboard());
        resetButton.addActionListener(e -> resetGame());
        input.addActionListener(e -> play());

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private User createUser() {
        JTextField usernameField = new JTextField();
        JComboBox<String> roleBox = new JComboBox<>(new String[]{"Player", "Admin"});

        JPanel panel = new JPanel(new GridLayout(0, 1, 5, 5));
        panel.add(new JLabel("Username:"));
        panel.add(usernameField);
        panel.add(new JLabel("Role:"));
        panel.add(roleBox);

        JOptionPane.showMessageDialog(null, panel, "User Setup", JOptionPane.PLAIN_MESSAGE);

        String username = usernameField.getText().trim();
        String role = String.valueOf(roleBox.getSelectedItem());

        if ("Admin".equals(role)) {
            return new AdminUser(username.isEmpty() ? "Admin" : username);
        }
        return new PlayerUser(username.isEmpty() ? "Player1" : username);
    }

    private Difficulty chooseDifficulty() {
        JComboBox<Difficulty> difficultyBox = new JComboBox<>(Difficulty.values());
        JPanel panel = new JPanel(new GridLayout(0, 1, 5, 5));
        panel.add(new JLabel("Select difficulty:"));
        panel.add(difficultyBox);

        JOptionPane.showMessageDialog(null, panel, "Difficulty", JOptionPane.PLAIN_MESSAGE);
        return (Difficulty) difficultyBox.getSelectedItem();
    }

    private void play() {
        int guess;

        try {
            guess = Integer.parseInt(input.getText().trim());
        } catch (Exception e) {
            output.append("Enter number only" + System.lineSeparator());
            input.setText("");
            return;
        }

        if (guess < 0 || guess > game.getMax()) {
            output.append("Invalid input. Enter 0 to " + game.getMax() + System.lineSeparator());
            input.setText("");
            return;
        }

        if (top < guesses.length - 1) {
            guesses[++top] = guess;
        }

        String result = game.check(guess);

        if ("win".equals(result)) {
            output.append("WIN | Score: " + game.getScore() + System.lineSeparator());
            leaderboard.addEntry(new LeaderboardEntry(
                    currentUser.getUsername(),
                    currentUser.getRole(),
                    game.getDifficulty().getLabel(),
                    game.getLevel(),
                    game.getScore()
            ));
            game.nextLevel();
            resetGuesses();
            output.append("Level up. New range: 0 to " + game.getMax() + System.lineSeparator());
        } else if ("greater".equals(result)) {
            output.append("Greater" + System.lineSeparator());
        } else {
            output.append("Smaller" + System.lineSeparator());
        }

        if (game.getAttempts() >= game.getMaxAttempts() && !"win".equals(result)) {
            output.append("Game Over. Number was: " + game.getNumber() + System.lineSeparator());
            game.resetGame();
            resetGuesses();
            output.append("New game started. Guess a number from 0 to " + game.getMax() + System.lineSeparator());
        }

        output.append("Guesses: " + getGuesses() + System.lineSeparator());
        output.append(System.lineSeparator());

        input.setText("");
        updateLabels();
    }

    private void updateLabels() {
        userLabel.setText("User: " + currentUser.getUsername() + " (" + currentUser.getRole() + ")");
        levelLabel.setText("Level: " + game.getLevel());
        scoreLabel.setText("Score: " + game.getScore());
        infoLabel.setText("Difficulty: " + game.getDifficulty().getLabel() + " | Attempts: " + game.getAttempts() + "/" + game.getMaxAttempts());
    }

    private String getGuesses() {
        if (top == -1) {
            return "None";
        }

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i <= top; i++) {
            sb.append(guesses[i]).append(' ');
        }
        return sb.toString().trim();
    }

    private void resetGuesses() {
        top = -1;
    }

    private void showLeaderboard() {
        output.append("=== Leaderboard ===" + System.lineSeparator());
        output.append(leaderboard.formatTopEntries(10));
        output.append(System.lineSeparator());
    }

    private void clearLeaderboard() {
        leaderboard.clear();
        output.append("Leaderboard cleared by admin." + System.lineSeparator() + System.lineSeparator());
    }

    private void resetGame() {
        game.resetGame();
        resetGuesses();
        output.append("Game reset. Guess a number from 0 to " + game.getMax() + System.lineSeparator() + System.lineSeparator());
        updateLabels();
        input.setText("");
    }
}
