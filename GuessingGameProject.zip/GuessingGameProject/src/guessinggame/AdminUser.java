package guessinggame;

public class AdminUser extends User {
    public AdminUser(String username) {
        super(username);
    }

    @Override
    public String getRole() {
        return "Admin";
    }

    public boolean canClearLeaderboard() {
        return true;
    }
}
