package guessinggame;

public class PlayerUser extends User {
    public PlayerUser(String username) {
        super(username);
    }

    @Override
    public String getRole() {
        return "Player";
    }
}
